const calculateWeightLostInAMonth = (cycling,running,swimming,extraCalorieInTake) =>{
   let weightLostInAMonth = 0;

   // write logic here 
   /* const cyclingCalories = 300;
   const runningCalories = 500;
   const swimmingCalories = 200; */   
   if (cycling<=0 || running<=0 || swimming<=0 || extraCalorieInTake<=0) {
      weightLostInAMonth = -1;
   }
   else{
      weightLostInAMonth = (
         (
            (2*cycling*4) + (2*running*4) + (2*swimming*4) 
         ) - ( extraCalorieInTake*30 ) 
      ) / 1000;
   }
   return weightLostInAMonth;
   
}
   
module.exports = calculateWeightLostInAMonth